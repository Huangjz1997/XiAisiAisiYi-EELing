import java.util.ArrayList;

public class Team {

	private String name;
	private double totalgrade;
	private int num_of_grade;
	private ArrayList<Student> members;

	/**
	 * 
	 * constructor
	 *
	 */
	public Team() {

		this.members = new ArrayList<>();
		this.totalgrade = 0;
		this.num_of_grade = 0;
	}

	/**
	 * 
	 * constructor
	 *
	 * @param teamName
	 */
	public Team(String teamName) {
		this.members = new ArrayList<>();
		this.name = teamName;
		this.totalgrade = 0;
		this.num_of_grade = 0;
	}

	/**
	 * 
	 * add a new student into the team
	 *
	 * @param newmember
	 */
	public void addmember(Student newmember) {
		if (!this.members.contains(newmember))
			this.members.add(newmember);
	}

	/**
	 * 
	 * add a new grade into the team
	 *
	 * @param newgrade
	 */
	public void addgrade(double newgrade) {

		this.totalgrade += newgrade;
		this.num_of_grade++;
		for (int i = 0; i < this.members.size(); i++) {
			Student nowstudent = this.members.get(i);
			nowstudent.addgrade(newgrade);
		}

	}

	/**
	 * 
	 * return the name of the team
	 *
	 * @return
	 */
	public String getName() {

		return this.name;
	}

	/**
	 * 
	 * return the average grade of this team
	 *
	 * @return
	 */
	public long getGrade() {
		if (this.num_of_grade == 0)
			return 0;
		return Math.round(this.totalgrade / this.num_of_grade);
	}

}
