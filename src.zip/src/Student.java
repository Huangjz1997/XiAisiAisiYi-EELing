public class Student {
	private String name;
	private double totalgrade;
	private int num_of_grade;

	/**
	 * makes a new student object
	 * 
	 * @param newName
	 *            the name of the student
	 */
	public Student(String newName) {
		this.name = newName;
		this.totalgrade = 0;
		this.num_of_grade = 0;

	}

	/**
	 * 
	 * add a new grade into the student
	 *
	 * @param grade
	 */
	public void addgrade(double grade) {

		this.totalgrade += grade;
		this.num_of_grade++;
	}

	/**
	 * 
	 * gets the average grade of the student
	 *
	 * @return
	 */
	public long getgrade() {
		if (this.num_of_grade == 0)
			return 0;
		return Math.round(this.totalgrade / this.num_of_grade);
	}

	/**
	 * gets the name of the student
	 * 
	 * @return the name of the student
	 */
	public String getName() {
		return this.name;
	}

}
